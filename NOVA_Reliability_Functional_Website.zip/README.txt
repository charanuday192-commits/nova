NOVA Reliability functional website.
Open index.html in Chrome/Edge/Firefox.
No server or API key is required.
Demo: Dashboard -> Customer -> search Milk -> Find reliable option -> confirm order.
Also explore Stores, Orders and Analytics.
Synthetic data is based on the supplied NOVA CART case.
